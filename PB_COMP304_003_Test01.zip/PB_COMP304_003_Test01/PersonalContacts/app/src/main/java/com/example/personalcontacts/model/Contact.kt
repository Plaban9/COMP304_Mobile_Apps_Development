package com.example.personalcontacts.model

import java.sql.Timestamp

data class Contacts(val id: Int, val name: String, val address: String, val contactNumber: String, val contactType: String)